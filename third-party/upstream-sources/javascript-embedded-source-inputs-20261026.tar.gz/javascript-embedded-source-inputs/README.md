# Embedded JavaScript source inputs

The archive preserves decoded PDF-lib source-map modules, exact JSZip pako
module bodies and versioned package source/data/license inputs. SOURCE-INDEX.json
records byte identities, module associations and the verified scope. Files
retained from packages or decoded sources have not been edited. JSZip's three
small dependency modules match their package browser inputs after removal of
the Browserify global wrapper and terminal whitespace. The sixteen pako module
bodies preserve the exact bundled JavaScript and original source notices.

This is a selected source-input archive, not a full original registry archive.
PDF-lib's original TypeScript, build configuration and lockfile and JSZip's
original JavaScript/build configuration and lockfile are in their separate
source archives. The standard-fonts package input here includes generated
JavaScript and compressed data; its preferred TypeScript and original font
and encoding preparation inputs remain a source requirement.

The readable-stream dependency and its support packages are not embedded in
this browser build: JSZip maps that import to its stream adapter with an
external stream reference. The Browserify loader remains in the original
unminified JSZip bundle; the exact original loader-source revision has not
been independently matched. General-purpose compiler sources and a byte-identical
rebuild are separate from these preferred-source and notice requirements.
